import java.util.Scanner;

public class ApRefrescos{
	public static void main(String[] args){
		Stock miStock = new Stock();
		Scanner leer= new Scanner(System.in);
		int producto;
			miStock.llenarRieles();
		do{
			
			miStock.mostrarStock();
			
			System.out.println("¿Qué producto desea? (1-8)");
			producto = leer.nextInt();
			System.out.println(miStock.getRieles(producto-1));
			if(producto !=0 && miStock.getRieles(producto-1)>0){
				System.out.println("Despacharemos un producto "+producto);
				producto--;
				miStock.despachar(producto);
				producto++;
			}
		}while(producto != 0);
		
		System.out.println("Apagando maquina...");	
	}
}